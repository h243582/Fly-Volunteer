package com.heyufei.utils;

import java.util.UUID;

public class UUIDmy {
    public static String getUUID(){
        return "2022"+UUID.randomUUID().toString().replaceAll("\\D","").substring(0,6);
    }
    public static String getPhone(){
        return "16"+UUID.randomUUID().toString().replaceAll("\\D","").substring(0,9);
    }
}
