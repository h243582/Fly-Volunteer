package com.heyufei.pojo;

import lombok.Data;

import java.util.Map;

@Data
public class BaseQuery<T> {
    private Integer index = 0;
    private Integer pageNum;
    private Integer pageSize;
    private Integer field;
    private String type;
    private T param;
    Map<String,Object> paramMap;
    public BaseQuery(){
        this.pageNum = 1;
        this.pageSize = 5;
    }

    public BaseQuery(Integer pageNum, Integer pageSize) {
        this.pageNum = pageNum;
        this.pageSize = pageSize;
    }

    public BaseQuery(Integer index, Integer pageNum, Integer pageSize) {
        this.index = index;
        this.pageNum = pageNum;
        this.pageSize = pageSize;
    }



}
