package com.heyufei.service;

import com.heyufei.dao.UserMapper;
import com.heyufei.pojo.Menu;
import com.heyufei.pojo.User;

import java.util.List;

public class UserServiceImpl implements UserService {
    UserMapper userMapper;

    public void setUserMapper(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public Integer queryUsername(String username) {
        return userMapper.queryUsername(username);
    }

    @Override
    public User queryUserByLogin(String username, String password) {
        return userMapper.queryUserByLogin(username,password);
    }

    @Override
    public Integer queryPhone(String phone) {
        return userMapper.queryPhone(phone);
    }

    @Override
    public void addUser(User user) {
        userMapper.addUser(user);
    }

    @Override
    public List<Menu> queryMenuByUsername(String username) {
        return userMapper.queryMenuByUsername(username);
    }

    @Override
    public List<User> queryAllUser(Integer index) {
        return userMapper.queryAllUser(index);
    }

    @Override
    public Integer queryAllUserCount() {
        return userMapper.queryAllUserCount();
    }

    @Override
    public Integer deleteUser(int id) {
        return userMapper.deleteUser(id);
    }

    @Override
    public Integer updateUser(User user) {
        return userMapper.updateUser(user);
    }

    @Override
    public void picAdd(int userId, String picUrl) {
        userMapper.picAdd(userId,picUrl);
    }

    @Override
    public void picUpdate(int userId, String picUrl) {
        userMapper.picUpdate(userId, picUrl);
    }

    @Override
    public String picQueryUrl(int userId) {
        return userMapper.picQueryUrl(userId);
    }

}
