package com.heyufei.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyInterceptor implements HandlerInterceptor {
    /**
     * 在请求处理的方法之前执行
     * @return 返回true执行下一个拦截器，false就不执行下一个拦截器
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 如果是登陆页面则放行
        String uri = request.getRequestURI();///isUsername
        String url = String.valueOf(request.getRequestURL());//http://localhost:8020/isUsername

        System.out.print("uri: " + uri);
//        System.out.println("url: " + url);
        System.out.print("---------");
        if (uri.contains("login")||uri.contains("register")||uri.contains("index")||uri.contains("Login")
                ||uri.contains("isUsername")||uri.contains("1")||uri.contains("swagger")||uri.contains("upload")
                ||request.getSession().getAttribute("user") != null) {
            System.out.println("允许访问");
            return true;
        }
        // 用户没有登陆跳转到登陆页面
        request.getRequestDispatcher("/index.html").forward(request, response);
        return false;
    }

    // 在请求处理方法执行之后执行
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);    }

    //在dispatcherServlet处理后执行,做清理工作.
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        HandlerInterceptor.super.afterCompletion(request, response, handler, ex);    }
}