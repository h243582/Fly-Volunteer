package com.heyufei.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageInfo;
import com.heyufei.pojo.BaseQuery;
import com.heyufei.pojo.Menu;
import com.heyufei.pojo.User;
import com.heyufei.service.UserService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
public class UserController {
    @Autowired
    @Qualifier("userMapperImpl")
    private UserService userService;

    private Integer usersCount = null;
    private Map<String, Object> map = new HashMap<>();

    @RequestMapping("/login")
    public String login(@RequestParam("username") String username, @RequestParam("password") String password, Model model, HttpServletRequest request) throws IOException {
        User user = userService.queryUserByLogin(username, password);
        System.out.println(user);
        if (user != null) {
            request.getSession().setAttribute("user", user);

            List<Menu> menus = userService.queryMenuByUsername(user.getUsername());
            request.getSession().setAttribute("menus", menus);

            User user1 = userService.queryUserByLogin(user.getUsername(), user.getPassword());
            request.getSession().setAttribute("picUrl",userService.picQueryUrl(user1.getId()));

            return "/app/application.jsp";
        } else {
            request.getSession().setAttribute("msg", -1);
            return "/index.html";
        }
    }


    @RequestMapping("/queryAllUser")
    @ResponseBody
    public Map<String,Object> queryAllUser(int index,HttpServletRequest request) throws IOException {
        if (this.usersCount == null){
            usersCount = userService.queryAllUserCount();
            System.out.println(usersCount);
            request.getSession().setAttribute("usersCount",usersCount);
        }

        request.getSession().setAttribute("index",index);

        List<User> list = userService.queryAllUser(index);
        map.put("data", list);
        map.put("userCounts",this.usersCount);

        System.out.println("usersCount:   "+request.getSession().getAttribute("usersCount"));
        return map;
    }

    @RequestMapping("/deleteUser")
    @ResponseBody
    public Object deleteUser(int id ,HttpServletRequest request) throws IOException {
        System.out.println(id);
        userService.deleteUser(id);
        return id;
    }

    @RequestMapping("/updateUser")
    @ResponseBody
    public  Map<String,Object> updateUser(User user,int index ,HttpServletRequest request) throws IOException {
        System.out.println("updateUser:  "+user);
        System.out.println("updateUser:  "+index);
        userService.updateUser(user);


        List<User> list = userService.queryAllUser(index);
        map.put("data", list);
        return map;

    }

    @RequestMapping("/outLogin")
    public  String outLogin(HttpServletRequest request) throws IOException {
        request.getSession().setAttribute("user",null);
        request.getSession().setAttribute("menus",null);
        request.getSession().setAttribute("picUrl",null);
        request.getSession().setAttribute("picUrl",null);
        return "redirect:index.html";

    }
}

