package com.heyufei.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 权限菜单类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Menu {
    private int id;
    private String menuName;
    private int modeId;
    private String url;
    private String target;
}
