package com.heyufei.service;


import com.heyufei.pojo.Menu;
import com.heyufei.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserService {

    Integer queryUsername(String username);

    User queryUserByLogin(String username, String password);

    //电话是不是已经注册
    Integer queryPhone(@Param("phone") String phone);

    //添加一个新用户
    void addUser(User user);

    //显示菜单
    List<Menu> queryMenuByUsername(@Param("username") String username);

    //获取所有用户
    List<User> queryAllUser(Integer index);

    //获取所有用户数
    Integer queryAllUserCount();

    //删除一个用户
    Integer deleteUser(int id);

    //删除一个用户
    Integer updateUser(User user);



    void picAdd(int userId, String picUrl);

    void picUpdate(int userId, String picUrl);

    String picQueryUrl(@Param("userId") int userId);

}
