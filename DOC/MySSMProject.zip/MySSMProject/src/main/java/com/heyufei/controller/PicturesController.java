package com.heyufei.controller;

import com.heyufei.utils.OSS_Tencent;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


@Controller
public class PicturesController {

    //采用file.transferTo 来保存上传的文件
    @RequestMapping("/uploadPic")
    @ResponseBody
    public String fileUpload1(@RequestParam("file") CommonsMultipartFile imgFile, HttpServletRequest request) throws IOException {
        //获取文件名 : file.getOriginalFilename();
        String uploadFileName = imgFile.getOriginalFilename();
        System.out.println("上传文件名 : "+uploadFileName);
        //如果文件名为空，直接回到首页！
        if ("".equals(uploadFileName)){
//            return "app/register.jsp";
            return null;
        }

        //上传路径保存设置
        String path = request.getServletContext().getRealPath("/upload");
        System.out.println("path----------------------"+path);
        //如果路径不存在，创建一个
        File realPath = new File(path);
        if (!realPath.exists()){
            realPath.mkdir();
        }
        System.out.println("上传文件保存地址："+realPath);

        OSS_Tencent oss = new OSS_Tencent();
        String picPath = realPath.getAbsolutePath() + "\\" + uploadFileName;
        String httpUrl = oss.upload(picPath, uploadFileName);
        System.out.println("httpUrl:  "+httpUrl);
        return httpUrl;
    }

    @RequestMapping("/uploadToFile")
    @ResponseBody
    public String uploadToUser(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
        String fileName = file.getOriginalFilename();
        String upload;
        System.out.println(fileName);
        if (fileName.indexOf("\\") != -1) {
            fileName = fileName.substring(fileName.lastIndexOf("\\"));
        }
        System.out.println(fileName);

        // 获取文件存放地址
        String filePath = request.getServletContext().getRealPath("/upload/");;
        File f = new File(filePath);
        if (!f.exists()) {
            f.mkdirs();// 不存在路径则进行创建
        }
        FileOutputStream out = null;
        try {
            // 重新自定义文件的名称
            Date date = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            String d = sdf.format(date);// 时间

            //名字
            fileName =  d + fileName.substring(fileName.indexOf('.'));
            filePath = filePath + fileName;
            System.out.println(filePath);
            out = new FileOutputStream(filePath);
            out.write(file.getBytes());
            out.flush();
            out.close();

            OSS_Tencent oss = new OSS_Tencent();
            upload = oss.upload(filePath,  fileName);
        } catch (Exception e) {
            return "error";
        }
        request.getSession().setAttribute("picUrl",upload);

        return upload; // 返回文件地址
    }

//    //采用file.transferTo 来保存上传的文件
//    @RequestMapping("/uploadPic2")
//    @ResponseBody
//    public String fileUpload2(@RequestParam("imgFile") MultipartFile  file, HttpServletRequest request) throws IOException {
//        String fileName = file.getOriginalFilename();
//        if (fileName.indexOf("\\") != -1) {
//            fileName = fileName.substring(fileName.lastIndexOf("\\"));
//        }
//        // 获取文件存放地址
//        String filePath = dataPath;
//        File f = new File(filePath);
//        if (!f.exists()) {
//            f.mkdirs();// 不存在路径则进行创建
//        }
//        FileOutputStream out = null;
//        try {
//            // 重新自定义文件的名称
//            Date date = new Date();
//            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
//            String d = sdf.format(date);// 时间
//            filePath = filePath + d + fileName;
//            out = new FileOutputStream(filePath);
//            out.write(file.getBytes());
//            out.flush();
//            out.close();
//        } catch (Exception e) {
//            return "error";
//        }
//        return filePath; // 返回文件地址
//    }


}
