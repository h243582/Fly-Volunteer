package com.heyufei.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class userInformation {
    private Integer userId;
    private Integer birthday;
    private Integer marriage;//婚否
    private Integer province;//省份
    private Integer city;
    private Integer workPhone;//办公电话
    private Integer address;//用户地址
    private Integer email;
    private Integer qq;
    private Integer familyPhone;//家庭电话
    private Integer familyAddress;
    private Integer familyPostcode;//家庭地址邮编
    private Integer remark;//备注
    private Integer bestMan;//优秀员工



}
