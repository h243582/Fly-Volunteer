package com.heyufei.controller;

import com.heyufei.pojo.Menu;
import com.heyufei.pojo.User;
import com.heyufei.service.UserService;
import com.heyufei.utils.UUIDmy;
import org.apache.ibatis.annotations.Param;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class AjaxController {
    @Autowired
    @Qualifier("userMapperImpl")
    private UserService userService;

    @RequestMapping("/isUsername")
    public void isUsername(String username, HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setCharacterEncoding("utf-8");
        request.getSession().setAttribute("msg", 1);
        Integer name = userService.queryUsername(username);
        Integer phone = userService.queryPhone(username);

        if (name != null || phone != null) {
            response.getWriter().print("账号存在");
        } else {
            response.getWriter().print("账号不存在");
        }


    }

    @RequestMapping("/isPhone")
    @ResponseBody
    public Object isPhone(String phone, HttpServletResponse response) throws IOException {
        response.setCharacterEncoding("utf-8");

        Integer integer = userService.queryPhone(phone);
        System.out.println(integer);
        Map<Integer,String> map = new HashMap<>();

        if (integer != null) {
            map.put(0,"false");
            map.put(1,"手机号重复");
        } else {
            map.put(0,"true");
            map.put(1,"手机号可用");
        }
        return map;
    }

    @RequestMapping("/register")
    @ResponseBody
    public void register(@Param("phone") String phone,@Param("password")  String password, @Param("name") String name,
                      @Param("sex")  String sex,
                      @Param("purviewId") String purviewId, @Param("department") String department, @Param("position") String position,
                      @Param("picURL") String picURL, HttpServletRequest request) throws IOException {

        User user = new User();
        user.setUsername(UUIDmy.getUUID());
        user.setPhone(phone);
        user.setPassword(password);
        user.setName(name);
        user.setSex(sex);
        user.setPurviewId(Integer.parseInt(purviewId));
        user.setDepartment(department);
        user.setPosition(position);
        System.out.println(user);
        userService.addUser(user);

        User user1 = userService.queryUserByLogin(user.getUsername(), user.getPassword());
        userService.picAdd(user1.getId(),picURL);



    }
}
