import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.heyufei.pojo.User;
import com.heyufei.service.UserService;
import com.heyufei.service.UserServiceImpl;
import com.heyufei.utils.OSS_Tencent;
import com.heyufei.utils.UUIDmy;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.*;

public class demo {

    @Test
    public void de() throws JsonProcessingException {
        ApplicationContext context = new ClassPathXmlApplicationContext("application-context.xml");
        UserService userService = (UserService) context.getBean("userMapperImpl");

//        userService.picUpdate(2,"https://heyufei-1305336662.cos.ap-shanghai.myqcloud.com/my_img/202108261912309.png");
//
        System.out.println(userService.picQueryUrl(2));;

//        OSS_Tencent oss = new OSS_Tencent();
//        oss.upload("C:\\Users\\24358\\Desktop\\top1.gif","top1.gif");
//        oss.show();
//        oss.download();
//        oss.uploadImg();
//        oss.close();

//       String fileName ="041背景.jpg";
//        System.out.println(fileName.substring(fileName.indexOf('.')));
//        System.out.println(fileName.substring(5));


    }
}
